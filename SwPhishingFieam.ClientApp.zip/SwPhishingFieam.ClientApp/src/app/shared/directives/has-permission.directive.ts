import { Directive, Input, TemplateRef, ViewContainerRef, effect, inject } from '@angular/core';
import { AuthService } from '../../core/services/auth.service';

@Directive({
  selector: '[hasPermission]',
  standalone: true
})
export class HasPermissionDirective {
  private readonly templateRef = inject(TemplateRef<unknown>);
  private readonly viewContainer = inject(ViewContainerRef);
  private readonly authService = inject(AuthService);

  private permissaoDesejada = '';
  private foiRenderizado = false;

  @Input()
  set hasPermission(permissao: string) {
    this.permissaoDesejada = permissao;
    this.atualizarVisualizacao();
  }

  constructor() {
    effect(() => {
      // Reavalia dinamicamente sempre que o sinal de permissões do usuário mudar
      this.authService.permissoes();
      this.atualizarVisualizacao();
    });
  }

  private atualizarVisualizacao(): void {
    if (!this.permissaoDesejada) {
      this.limparView();
      return;
    }

    const temPermissao = this.authService.hasPermission(this.permissaoDesejada);

    if (temPermissao && !this.foiRenderizado) {
      this.viewContainer.createEmbeddedView(this.templateRef);
      this.foiRenderizado = true;
    } else if (!temPermissao && this.foiRenderizado) {
      this.limparView();
    }
  }

  private limparView(): void {
    this.viewContainer.clear();
    this.foiRenderizado = false;
  }
}
