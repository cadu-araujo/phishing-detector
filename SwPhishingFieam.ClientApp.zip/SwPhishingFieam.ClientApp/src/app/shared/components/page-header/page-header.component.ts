import { Component, Input } from '@angular/core';
import { CommonModule } from '@angular/common';

@Component({
  selector: 'app-page-header',
  standalone: true,
  imports: [CommonModule],
  template: `
    <div class="d-flex justify-content-between align-items-center mb-4 pb-2 border-bottom">
      <div>
        <h2 class="h4 mb-1 fw-bold text-dark">{{ titulo }}</h2>
        <p class="text-muted small mb-0" *ngIf="subtitulo">{{ subtitulo }}</p>
      </div>
      <div>
        <ng-content select="[acoes]"></ng-content>
      </div>
    </div>
  `
})
export class PageHeaderComponent {
  @Input({ required: true }) titulo = '';
  @Input() subtitulo = '';
}
