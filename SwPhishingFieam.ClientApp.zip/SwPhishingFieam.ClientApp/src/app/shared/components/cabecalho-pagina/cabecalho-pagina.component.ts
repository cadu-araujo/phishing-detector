import { Component, ChangeDetectionStrategy, input } from '@angular/core';

export interface MigalhaItem {
  rotulo: string;
  rota?: string;
}

@Component({
  selector: 'app-cabecalho-pagina',
  changeDetection: ChangeDetectionStrategy.OnPush,
  template: `
    <header class="cabecalho-pagina mb-4">
      <div class="d-flex flex-wrap align-items-center justify-content-between gap-3">
        <div>
          @if (migalhas().length > 0) {
            <nav aria-label="Navegação estrutural" class="mb-1">
              <ol class="breadcrumb mb-0">
                @for (item of migalhas(); track item.rotulo; let ultima = $last) {
                  @if (ultima) {
                    <li class="breadcrumb-item active" aria-current="page">{{ item.rotulo }}</li>
                  } @else {
                    <li class="breadcrumb-item">
                      <a [href]="item.rota || '#'" class="text-decoration-none">{{ item.rotulo }}</a>
                    </li>
                  }
                }
              </ol>
            </nav>
          }
          <div class="d-flex align-items-center gap-2">
            @if (icone()) {
              <span class="material-symbols-outlined icone-titulo" aria-hidden="true">{{ icone() }}</span>
            }
            <h1 class="h3 mb-0 fw-bold titulo-pagina">{{ titulo() }}</h1>
          </div>
          @if (descricao()) {
            <p class="text-muted mb-0 mt-1 small">{{ descricao() }}</p>
          }
        </div>
        <div class="acoes-cabecalho d-flex align-items-center gap-2">
          <ng-content select="[acoes]" />
        </div>
      </div>
    </header>
  `,
  styles: `
    .cabecalho-pagina {
      padding-bottom: 1rem;
      border-bottom: 1px solid var(--bs-border-color, #c4c6d2);
    }
    .icone-titulo {
      font-size: 2rem;
      color: var(--bs-primary, #2957A4);
    }
    .titulo-pagina {
      color: var(--bs-body-color, #0b1c30);
      letter-spacing: -0.02em;
    }
    .breadcrumb-item {
      font-size: 0.8125rem;
      a {
        color: var(--bs-primary, #2957A4);
      }
    }
  `
})
export class CabecalhoPaginaComponent {
  readonly titulo = input.required<string>();
  readonly descricao = input<string>('');
  readonly icone = input<string>('');
  readonly migalhas = input<MigalhaItem[]>([]);
}
