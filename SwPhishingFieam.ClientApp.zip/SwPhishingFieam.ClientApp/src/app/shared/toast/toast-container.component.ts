import { AsyncPipe } from '@angular/common';
import { Component, inject } from '@angular/core';
import { ToastService } from './toast.service';

@Component({
  selector: 'app-toast-container',
  imports: [AsyncPipe],
  template: `
    <section class="toast-stack" aria-live="polite" aria-label="Notificações">
      @for (notificacao of servicoToast.notificacoes$ | async; track notificacao.id) {
        <button
          type="button"
          [class]="'toast-item toast--' + notificacao.tipo"
          (click)="servicoToast.remover(notificacao.id)"
        >
          <span class="material-symbols-outlined icone-toast" aria-hidden="true">
            @switch (notificacao.tipo) {
              @case ('sucesso') { check_circle }
              @case ('erro') { error }
              @case ('aviso') { warning }
              @default { info }
            }
          </span>
          <span class="mensagem-toast">{{ notificacao.mensagem }}</span>
        </button>
      }
    </section>
  `,
  styles: `
    .toast-stack {
      display: grid;
      gap: 0.75rem;
      inset: auto 1.5rem 1.5rem auto;
      max-width: min(26rem, calc(100vw - 3rem));
      position: fixed;
      z-index: 1200;
    }

    .toast-item {
      align-items: center;
      background: #ffffff;
      border: 1px solid var(--bs-border-color, #c4c6d2);
      border-left: 0.35rem solid var(--bs-primary, #2957A4);
      border-radius: 0.5rem;
      box-shadow: 0 0.5rem 1.5rem rgba(11, 28, 48, 0.12);
      color: #0b1c30;
      cursor: pointer;
      display: flex;
      font-weight: 600;
      font-size: 0.875rem;
      gap: 0.75rem;
      padding: 0.875rem 1.25rem;
      text-align: left;
      transition: transform 0.2s cubic-bezier(0.4, 0, 0.2, 1);

      &:hover {
        transform: translateY(-2px);
      }
    }

    .icone-toast {
      font-size: 1.25rem;
      flex-shrink: 0;
    }

    .mensagem-toast {
      flex: 1;
      line-height: 1.35;
    }

    .toast--sucesso {
      border-left-color: #16a34a;
      .icone-toast { color: #16a34a; }
    }

    .toast--aviso {
      border-left-color: #f59e0b;
      .icone-toast { color: #f59e0b; }
    }

    .toast--erro {
      border-left-color: #ba1a1a;
      .icone-toast { color: #ba1a1a; }
    }

    .toast--informacao {
      border-left-color: #0098DA;
      .icone-toast { color: #0098DA; }
    }
  `
})
export class ToastContainerComponent {
  readonly servicoToast = inject(ToastService);
}
