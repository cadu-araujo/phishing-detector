import { Injectable } from '@angular/core';
import { BehaviorSubject } from 'rxjs';

export interface Toast {
  readonly id: number;
  readonly mensagem: string;
  readonly tipo: 'sucesso' | 'erro' | 'aviso' | 'informacao';
  readonly duracao: number;
}

@Injectable({ providedIn: 'root' })
export class ToastService {
  private static proximoId = 0;
  private readonly notificacoesSubject = new BehaviorSubject<readonly Toast[]>([]);

  readonly notificacoes$ = this.notificacoesSubject.asObservable();

  exibir(mensagem: string, tipo: Toast['tipo'] = 'sucesso', duracao = 4_000): void {
    const notificacao: Toast = {
      id: ToastService.proximoId++,
      mensagem,
      tipo,
      duracao
    };
    this.notificacoesSubject.next([...this.notificacoesSubject.value, notificacao]);
    window.setTimeout(() => this.remover(notificacao.id), duracao);
  }

  sucesso(mensagem: string): void {
    this.exibir(mensagem, 'sucesso');
  }

  erro(mensagem: string): void {
    this.exibir(mensagem, 'erro', 6_000);
  }

  aviso(mensagem: string): void {
    this.exibir(mensagem, 'aviso', 5_000);
  }

  informacao(mensagem: string): void {
    this.exibir(mensagem, 'informacao');
  }

  remover(id: number): void {
    this.notificacoesSubject.next(
      this.notificacoesSubject.value.filter((notificacao) => notificacao.id !== id)
    );
  }
}
