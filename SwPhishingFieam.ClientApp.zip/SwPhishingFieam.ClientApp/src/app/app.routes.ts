import { Routes } from '@angular/router';
import { authGuard } from './core/guards/auth.guard';

export const routes: Routes = [
  {
    path: 'entrar',
    loadComponent: () => import('./layouts/publico/layout-publico.component').then(m => m.LayoutPublicoComponent),
    children: [
      {
        path: '',
        loadComponent: () => import('./features/autenticacao/login.component').then(m => m.LoginComponent)
      }
    ]
  },
  {
    path: '',
    loadComponent: () => import('./layouts/autenticado/layout-autenticado.component').then(m => m.LayoutAutenticadoComponent),
    children: [
      {
        path: '',
        loadComponent: () => import('./features/inicio/inicio.component').then(m => m.InicioComponent)
      },
      {
        path: 'campanhas',
        loadComponent: () => import('./features/inicio/inicio.component').then(m => m.InicioComponent)
      },
      {
        path: 'audiencia',
        canActivate: [authGuard],
        loadComponent: () => import('./features/audiencia/audiencia.component').then(m => m.AudienciaComponent)
      },
      {
        path: 'treinamentos',
        loadComponent: () => import('./features/inicio/inicio.component').then(m => m.InicioComponent)
      },
      {
        path: 'relatorios',
        loadComponent: () => import('./features/inicio/inicio.component').then(m => m.InicioComponent)
      },
      {
        path: 'administracao',
        loadComponent: () => import('./features/inicio/inicio.component').then(m => m.InicioComponent)
      }
    ]
  },
  {
    path: '**',
    redirectTo: ''
  }
];
