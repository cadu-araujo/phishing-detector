import { AsyncPipe } from '@angular/common';
import { ChangeDetectionStrategy, Component, HostListener, OnInit, inject, signal } from '@angular/core';
import { NavigationEnd, Router, RouterLink, RouterLinkActive, RouterOutlet } from '@angular/router';
import { filter } from 'rxjs';
import { AuthService } from '../../core/services/auth.service';
import { PresetCasaInstitucional, PRESETS_CASAS_INSTITUCIONAIS } from '../../core/tema/tema.models';
import { TemaService } from '../../core/tema/tema.service';
import { ToastService } from '../../shared/toast/toast.service';

export type GrupoMenu = 'campanhas' | 'audiencia' | 'treinamentos' | 'relatorios' | 'administracao';

@Component({
  selector: 'app-layout-autenticado',
  imports: [AsyncPipe, RouterLink, RouterLinkActive, RouterOutlet],
  templateUrl: './layout-autenticado.component.html',
  styleUrl: './layout-autenticado.component.css',
  changeDetection: ChangeDetectionStrategy.OnPush
})
export class LayoutAutenticadoComponent implements OnInit {
  readonly autenticacao = inject(AuthService);
  readonly tema = inject(TemaService);
  private readonly roteador = inject(Router);
  private readonly toast = inject(ToastService);

  readonly presetsCasas = PRESETS_CASAS_INSTITUCIONAIS;
  readonly casaAtiva = signal<PresetCasaInstitucional>(PRESETS_CASAS_INSTITUCIONAIS[0]);

  menuAberto = false;
  menuContextoAberto = false;
  menuUsuarioAberto = false;
  grupoAberto: GrupoMenu | null = 'campanhas';

  @HostListener('document:click')
  fecharMenusGlobais(): void {
    this.menuContextoAberto = false;
    this.menuUsuarioAberto = false;
  }

  ngOnInit(): void {
    this.ajustarGrupoPelaUrl(this.roteador.url);
    this.roteador.events
      .pipe(filter(evento => evento instanceof NavigationEnd))
      .subscribe(evento => {
        const url = (evento as NavigationEnd).urlAfterRedirects || (evento as NavigationEnd).url;
        this.ajustarGrupoPelaUrl(url);
      });
  }

  alternarMenu(): void {
    this.menuAberto = !this.menuAberto;
  }

  fecharMenu(): void {
    this.menuAberto = false;
  }

  alternarGrupo(grupo: GrupoMenu): void {
    this.grupoAberto = this.grupoAberto === grupo ? null : grupo;
  }

  isGrupoAberto(grupo: GrupoMenu): boolean {
    return this.grupoAberto === grupo;
  }

  alternarMenuContexto(evento: Event): void {
    evento.stopPropagation();
    this.menuContextoAberto = !this.menuContextoAberto;
    this.menuUsuarioAberto = false;
  }

  alternarMenuUsuario(evento: Event): void {
    evento.stopPropagation();
    this.menuUsuarioAberto = !this.menuUsuarioAberto;
    this.menuContextoAberto = false;
  }

  selecionarCasa(casa: PresetCasaInstitucional): void {
    this.casaAtiva.set(casa);
    this.tema.aplicarIdentidadeVisual({
      corPrimaria: casa.corPrimaria,
      corDestaque: casa.corDestaque,
      logomarcaClaraUrl: casa.logomarcaClaraUrl,
      logomarcaEscuraUrl: casa.logomarcaEscuraUrl
    });
    this.menuContextoAberto = false;
    this.toast.sucesso(`Entidade alternada para ${casa.nome}`);
  }

  obterIniciais(nome?: string | null): string {
    if (!nome) return 'US';
    const partes = nome.trim().split(' ').filter(Boolean);
    if (partes.length === 1) return partes[0].substring(0, 2).toUpperCase();
    return (partes[0][0] + partes[partes.length - 1][0]).toUpperCase();
  }

  sair(): void {
    this.autenticacao.limparSessao();
    this.toast.informacao('Sessão encerrada com sucesso.');
    this.roteador.navigate(['/entrar']);
  }

  private ajustarGrupoPelaUrl(url: string): void {
    if (url.includes('/campanhas')) {
      this.grupoAberto = 'campanhas';
    } else if (url.includes('/audiencia')) {
      this.grupoAberto = 'audiencia';
    } else if (url.includes('/treinamentos')) {
      this.grupoAberto = 'treinamentos';
    } else if (url.includes('/relatorios')) {
      this.grupoAberto = 'relatorios';
    } else if (url.includes('/administracao')) {
      this.grupoAberto = 'administracao';
    }
  }
}
