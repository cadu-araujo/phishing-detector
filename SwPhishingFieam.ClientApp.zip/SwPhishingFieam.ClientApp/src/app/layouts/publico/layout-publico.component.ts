import { Component, ChangeDetectionStrategy } from '@angular/core';
import { RouterOutlet } from '@angular/router';

@Component({
  selector: 'app-layout-publico',
  imports: [RouterOutlet],
  templateUrl: './layout-publico.component.html',
  styles: `
    .layout-publico {
      min-height: 100dvh;
      display: flex;
      flex-direction: column;
      background: var(--bs-body-bg, #f8f9ff);
    }
    .conteudo-publico {
      flex: 1;
      display: flex;
      align-items: center;
      justify-content: center;
    }
  `,
  changeDetection: ChangeDetectionStrategy.OnPush
})
export class LayoutPublicoComponent {}
