import { Injectable } from '@angular/core';
import { HttpClient, HttpParams } from '@angular/common/http';
import { Observable } from 'rxjs';

export interface ColaboradorResumo {
  id: string;
  entraIdObjectId: string;
  nome: string;
  email: string;
  cargo?: string;
  departamentoNome: string | null;
  unidadeSigla: string | null;
  ativo: boolean;
  dataAdmissao: string;
  ultimaSincronizacao: string;
  elegivel: boolean;
  statusElegibilidade: string;
  fimCooldownAte: string | null;
  motivoCooldown: string | null;
}

export interface PreviaAudiencia {
  totalGeral: number;
  totalElegiveis: number;
  totalExcluidosCooldown: number;
  totalExcluidosAdmissaoRecente: number;
  totalExcluidosInativos: number;
}

export interface ResultadoSincronizacao {
  totalProcessados: number;
  inseridos: number;
  atualizados: number;
  inativados: number;
  duracaoSegundos: number;
  mensagem: string;
}

export interface Departamento {
  id: string;
  nome: string;
  codigoEntraId: string | null;
  ativo: boolean;
}

export interface Unidade {
  id: string;
  sigla: string;
  razaoSocial: string;
  corPrimariaHex: string;
}

export interface GrupoSeguranca {
  id: string;
  entraIdGroupId: string;
  nomeGrupo: string;
  descricao: string | null;
}

export interface ColaboradorPaginadoResposta {
  total: number;
  pagina: number;
  tamanhoPagina: number;
  itens: ColaboradorResumo[];
}

@Injectable({
  providedIn: 'root'
})
export class AudienciaService {
  private readonly baseUrl = '/api/v1/alvos';

  constructor(private readonly http: HttpClient) {}

  listarColaboradores(
    unidadeId?: string,
    departamentoId?: string,
    grupoSegurancaId?: string,
    apenasAtivos?: boolean,
    ignorarCooldown: boolean = false,
    pagina: number = 1,
    tamanhoPagina: number = 20
  ): Observable<ColaboradorPaginadoResposta> {
    let params = new HttpParams()
      .set('pagina', pagina.toString())
      .set('tamanhoPagina', tamanhoPagina.toString())
      .set('ignorarCooldown', ignorarCooldown.toString());

    if (unidadeId) params = params.set('unidadeId', unidadeId);
    if (departamentoId) params = params.set('departamentoId', departamentoId);
    if (grupoSegurancaId) params = params.set('grupoSegurancaId', grupoSegurancaId);
    if (apenasAtivos !== undefined && apenasAtivos !== null) {
      params = params.set('apenasAtivos', apenasAtivos.toString());
    }

    return this.http.get<ColaboradorPaginadoResposta>(this.baseUrl, { params });
  }

  obterPrevia(filtro: {
    unidadeId?: string;
    departamentoId?: string;
    grupoSegurancaId?: string;
    ignorarCooldown?: boolean;
    apenasAtivos?: boolean;
  }): Observable<PreviaAudiencia> {
    return this.http.post<PreviaAudiencia>(`${this.baseUrl}/previa`, filtro);
  }

  sincronizarEntraId(): Observable<ResultadoSincronizacao> {
    return this.http.post<ResultadoSincronizacao>(`${this.baseUrl}/sincronizar`, {});
  }

  obterDepartamentos(): Observable<Departamento[]> {
    return this.http.get<Departamento[]>(`${this.baseUrl}/departamentos`);
  }

  obterUnidades(): Observable<Unidade[]> {
    return this.http.get<Unidade[]>(`${this.baseUrl}/unidades`);
  }

  obterGrupos(): Observable<GrupoSeguranca[]> {
    return this.http.get<GrupoSeguranca[]>(`${this.baseUrl}/grupos`);
  }
}
