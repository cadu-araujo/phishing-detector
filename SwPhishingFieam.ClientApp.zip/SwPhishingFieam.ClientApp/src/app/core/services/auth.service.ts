import { Injectable, signal, computed } from '@angular/core';
import { HttpClient } from '@angular/common/http';
import { Observable, tap } from 'rxjs';

export interface UsuarioSso {
  id: string;
  entraIdObjectId: string;
  nome: string;
  email: string;
  ativo: boolean;
  perfis: string[];
  permissoes: string[];
}

export interface AutenticacaoResposta {
  usuario: UsuarioSso;
  tokenAcesso: string;
  expiraEm: string;
}

@Injectable({
  providedIn: 'root'
})
export class AuthService {
  private readonly STORAGE_TOKEN_KEY = 'sw_phishing_token';
  private readonly STORAGE_USER_KEY = 'sw_phishing_user';

  private readonly _usuarioAtual = signal<UsuarioSso | null>(null);
  private readonly _token = signal<string | null>(null);

  readonly usuarioAtual = this._usuarioAtual.asReadonly();
  readonly estaAutenticado = computed(() => !!this._token());
  readonly permissoes = computed(() => this._usuarioAtual()?.permissoes ?? []);
  readonly perfis = computed(() => this._usuarioAtual()?.perfis ?? []);

  constructor(private readonly http: HttpClient) {
    this.carregarSessaoArmazenada();
  }

  private carregarSessaoArmazenada(): void {
    const tokenSalvo = localStorage.getItem(this.STORAGE_TOKEN_KEY);
    const usuarioSalvo = localStorage.getItem(this.STORAGE_USER_KEY);

    if (tokenSalvo && usuarioSalvo) {
      try {
        this._token.set(tokenSalvo);
        this._usuarioAtual.set(JSON.parse(usuarioSalvo));
      } catch {
        this.limparSessao();
      }
    }
  }

  autenticarSso(entraIdObjectId: string, nome: string, email: string): Observable<AutenticacaoResposta> {
    return this.http.post<AutenticacaoResposta>('/api/v1/auth/sso', {
      entraIdObjectId,
      nome,
      email
    }).pipe(
      tap(resposta => {
        this._token.set(resposta.tokenAcesso);
        this._usuarioAtual.set(resposta.usuario);

        localStorage.setItem(this.STORAGE_TOKEN_KEY, resposta.tokenAcesso);
        localStorage.setItem(this.STORAGE_USER_KEY, JSON.stringify(resposta.usuario));
      })
    );
  }

  obterToken(): string | null {
    return this._token();
  }

  hasPermission(permissao: string): boolean {
    const usuario = this._usuarioAtual();
    if (!usuario) return false;

    if (usuario.perfis.includes('AdministradorSegurancaGlobal')) {
      return true;
    }

    return usuario.permissoes.includes(permissao.toLowerCase());
  }

  hasRole(role: string): boolean {
    const usuario = this._usuarioAtual();
    if (!usuario) return false;
    return usuario.perfis.includes(role);
  }

  limparSessao(): void {
    this._token.set(null);
    this._usuarioAtual.set(null);
    localStorage.removeItem(this.STORAGE_TOKEN_KEY);
    localStorage.removeItem(this.STORAGE_USER_KEY);
  }
}
