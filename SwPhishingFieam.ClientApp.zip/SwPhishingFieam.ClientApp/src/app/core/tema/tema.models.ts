export interface ConfiguracaoIdentidadeVisual {
  readonly corPrimaria: string;
  readonly corDestaque: string;
  readonly logomarcaClaraUrl?: string | null;
  readonly logomarcaEscuraUrl?: string | null;
}

export interface PresetCasaInstitucional {
  readonly nome: string;
  readonly chave: string;
  readonly corPrimaria: string;
  readonly corDestaque: string;
  readonly logomarcaClaraUrl: string;
  readonly logomarcaEscuraUrl: string;
}

export const IDENTIDADE_VISUAL_PADRAO_FIEAM: ConfiguracaoIdentidadeVisual = {
  corPrimaria: '#2957A4',
  corDestaque: '#0098DA',
  logomarcaClaraUrl: 'assets/logos/logo_fieam_azul.png',
  logomarcaEscuraUrl: 'assets/logos/logo_fieam_branco.png'
};

export const PRESETS_CASAS_INSTITUCIONAIS: readonly PresetCasaInstitucional[] = [
  {
    nome: 'FIEAM',
    chave: 'fieam',
    corPrimaria: '#2957A4',
    corDestaque: '#0098DA',
    logomarcaClaraUrl: 'assets/logos/logo_fieam_azul.png',
    logomarcaEscuraUrl: 'assets/logos/logo_fieam_branco.png'
  },
  {
    nome: 'SESI',
    chave: 'sesi',
    corPrimaria: '#2957A4',
    corDestaque: '#6BBE50',
    logomarcaClaraUrl: 'assets/logos/logo_sesi_azul.png',
    logomarcaEscuraUrl: 'assets/logos/logo_sesi_branco.png'
  },
  {
    nome: 'SENAI',
    chave: 'senai',
    corPrimaria: '#2957A4',
    corDestaque: '#F15D36',
    logomarcaClaraUrl: 'assets/logos/logo_senai_azul.png',
    logomarcaEscuraUrl: 'assets/logos/logo_senai_branco.png'
  },
  {
    nome: 'IEL',
    chave: 'iel',
    corPrimaria: '#2957A4',
    corDestaque: '#66C6BB',
    logomarcaClaraUrl: 'assets/logos/logo_iel_azul.png',
    logomarcaEscuraUrl: 'assets/logos/logo_iel_branco.png'
  }
];
