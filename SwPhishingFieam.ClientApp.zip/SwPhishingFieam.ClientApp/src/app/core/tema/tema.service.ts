import { Injectable } from '@angular/core';
import { BehaviorSubject, map } from 'rxjs';
import { ConfiguracaoIdentidadeVisual, IDENTIDADE_VISUAL_PADRAO_FIEAM } from './tema.models';

@Injectable({ providedIn: 'root' })
export class TemaService {
  private readonly identidadeSubject = new BehaviorSubject<ConfiguracaoIdentidadeVisual>(
    IDENTIDADE_VISUAL_PADRAO_FIEAM
  );

  readonly identidadeAtiva$ = this.identidadeSubject.asObservable();
  readonly logomarcaClara$ = this.identidadeAtiva$.pipe(
    map(identidade => identidade.logomarcaClaraUrl || IDENTIDADE_VISUAL_PADRAO_FIEAM.logomarcaClaraUrl!)
  );
  readonly logomarcaEscura$ = this.identidadeAtiva$.pipe(
    map(identidade => identidade.logomarcaEscuraUrl || IDENTIDADE_VISUAL_PADRAO_FIEAM.logomarcaEscuraUrl!)
  );

  constructor() {
    this.aplicarTemaNoDom(IDENTIDADE_VISUAL_PADRAO_FIEAM);
  }

  get identidadeAtiva(): ConfiguracaoIdentidadeVisual {
    return this.identidadeSubject.value;
  }

  aplicarIdentidadeVisual(identidade?: ConfiguracaoIdentidadeVisual | null): void {
    const config = identidade
      ? {
          corPrimaria: identidade.corPrimaria || IDENTIDADE_VISUAL_PADRAO_FIEAM.corPrimaria,
          corDestaque: identidade.corDestaque || IDENTIDADE_VISUAL_PADRAO_FIEAM.corDestaque,
          logomarcaClaraUrl: identidade.logomarcaClaraUrl || IDENTIDADE_VISUAL_PADRAO_FIEAM.logomarcaClaraUrl,
          logomarcaEscuraUrl: identidade.logomarcaEscuraUrl || IDENTIDADE_VISUAL_PADRAO_FIEAM.logomarcaEscuraUrl
        }
      : IDENTIDADE_VISUAL_PADRAO_FIEAM;

    this.identidadeSubject.next(config);
    this.aplicarTemaNoDom(config);
  }

  redefinirParaPadrao(): void {
    this.aplicarIdentidadeVisual(IDENTIDADE_VISUAL_PADRAO_FIEAM);
  }

  private aplicarTemaNoDom(config: ConfiguracaoIdentidadeVisual): void {
    if (typeof document === 'undefined') return;

    const raiz = document.documentElement;
    const primRgb = this.hexParaRgb(config.corPrimaria) || '41, 87, 164';
    const accentRgb = this.hexParaRgb(config.corDestaque) || '0, 152, 218';

    raiz.style.setProperty('--bs-primary', config.corPrimaria);
    raiz.style.setProperty('--bs-primary-rgb', primRgb);
    raiz.style.setProperty('--casa-accent', config.corDestaque);
    raiz.style.setProperty('--casa-accent-rgb', accentRgb);
    raiz.style.setProperty('--primary', config.corPrimaria);
    raiz.style.setProperty('--accent', config.corDestaque);
  }

  private hexParaRgb(hex: string): string | null {
    if (!hex) return null;
    let corLimpa = hex.replace('#', '').trim();
    if (corLimpa.length === 3) {
      corLimpa = corLimpa.split('').map(c => c + c).join('');
    }
    if (corLimpa.length !== 6) return null;

    const r = parseInt(corLimpa.substring(0, 2), 16);
    const g = parseInt(corLimpa.substring(2, 4), 16);
    const b = parseInt(corLimpa.substring(4, 6), 16);

    if (isNaN(r) || isNaN(g) || isNaN(b)) return null;
    return `${r}, ${g}, ${b}`;
  }
}
