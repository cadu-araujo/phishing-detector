import { Component } from '@angular/core';
import { TestBed } from '@angular/core/testing';
import { provideRouter, Router } from '@angular/router';
import { RouterTestingHarness } from '@angular/router/testing';
import { routes } from '../../app.routes';
import { AuthService } from '../services/auth.service';

@Component({ template: 'Audiência' })
class AudienciaTeste {}

@Component({ template: 'Entrar' })
class LoginTeste {}

describe('Proteção da rota /audiencia', () => {
  const autenticacao = { estaAutenticado: () => false };

  beforeEach(() => {
    const audiencia = routes.find(route => route.path === '')!.children!
      .find(route => route.path === 'audiencia')!;

    TestBed.configureTestingModule({
      providers: [
        { provide: AuthService, useValue: autenticacao },
        provideRouter([
          { ...audiencia, loadComponent: () => AudienciaTeste },
          { path: 'entrar', component: LoginTeste }
        ])
      ]
    });
  });

  it('redireciona visitantes sem sessão para /entrar', async () => {
    autenticacao.estaAutenticado = () => false;
    const harness = await RouterTestingHarness.create();

    await harness.navigateByUrl('/audiencia', LoginTeste);

    expect(TestBed.inject(Router).url).toBe('/entrar');
  });

  it('permite abrir /audiencia com sessão autenticada', async () => {
    autenticacao.estaAutenticado = () => true;
    const harness = await RouterTestingHarness.create();

    await harness.navigateByUrl('/audiencia', AudienciaTeste);

    expect(TestBed.inject(Router).url).toBe('/audiencia');
  });
});
