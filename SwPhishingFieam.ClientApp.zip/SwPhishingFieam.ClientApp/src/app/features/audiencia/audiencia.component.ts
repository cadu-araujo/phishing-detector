import { Component, OnInit, signal, inject } from '@angular/core';
import { CommonModule } from '@angular/common';
import { FormsModule } from '@angular/forms';
import {
  AudienciaService,
  ColaboradorResumo,
  PreviaAudiencia,
  Unidade,
  Departamento,
  ResultadoSincronizacao
} from '../../core/services/audiencia.service';
import { ToastService } from '../../shared/toast/toast.service';

@Component({
  selector: 'app-audiencia',
  standalone: true,
  imports: [CommonModule, FormsModule],
  templateUrl: './audiencia.component.html',
  styleUrls: ['./audiencia.component.css']
})
export class AudienciaComponent implements OnInit {
  private readonly audienciaService = inject(AudienciaService);
  private readonly toastService = inject(ToastService);

  readonly carregando = signal<boolean>(false);
  readonly sincronizando = signal<boolean>(false);

  // Dados
  readonly colaboradores = signal<ColaboradorResumo[]>([]);
  readonly totalColaboradores = signal<number>(0);
  readonly previa = signal<PreviaAudiencia | null>(null);
  readonly unidades = signal<Unidade[]>([]);
  readonly departamentos = signal<Departamento[]>([]);

  // Filtros
  filtroUnidadeId = signal<string>('');
  filtroDepartamentoId = signal<string>('');
  filtroIgnorarCooldown = signal<boolean>(false);
  filtroApenasAtivos = signal<boolean>(true);

  // Paginação
  paginaAtual = signal<number>(1);
  tamanhoPagina = signal<number>(15);

  ngOnInit(): void {
    this.carregarMetadados();
    this.carregarDados();
  }

  carregarMetadados(): void {
    this.audienciaService.obterUnidades().subscribe({
      next: (dados) => this.unidades.set(dados),
      error: () => this.toastService.erro('Erro ao carregar lista de unidades.')
    });

    this.audienciaService.obterDepartamentos().subscribe({
      next: (dados) => this.departamentos.set(dados),
      error: () => this.toastService.erro('Erro ao carregar lista de departamentos.')
    });
  }

  carregarDados(): void {
    this.carregando.set(true);

    const unidId = this.filtroUnidadeId() || undefined;
    const depId = this.filtroDepartamentoId() || undefined;
    const ignorarCool = this.filtroIgnorarCooldown();
    const apenasAtivos = this.filtroApenasAtivos();

    // 1. Carregar contadores/prévia
    this.audienciaService.obterPrevia({
      unidadeId: unidId,
      departamentoId: depId,
      ignorarCooldown: ignorarCool,
      apenasAtivos
    }).subscribe({
      next: (resp) => this.previa.set(resp),
      error: () => this.toastService.erro('Erro ao calcular prévia de alvos.')
    });

    // 2. Carregar lista paginada
    this.audienciaService.listarColaboradores(
      unidId,
      depId,
      undefined,
      apenasAtivos,
      ignorarCool,
      this.paginaAtual(),
      this.tamanhoPagina()
    ).subscribe({
      next: (resp) => {
        this.colaboradores.set(resp.itens);
        this.totalColaboradores.set(resp.total);
        this.carregando.set(false);
      },
      error: () => {
        this.toastService.erro('Erro ao listar colaboradores.');
        this.carregando.set(false);
      }
    });
  }

  aplicarFiltros(): void {
    this.paginaAtual.set(1);
    this.carregarDados();
  }

  limparFiltros(): void {
    this.filtroUnidadeId.set('');
    this.filtroDepartamentoId.set('');
    this.filtroIgnorarCooldown.set(false);
    this.filtroApenasAtivos.set(true);
    this.paginaAtual.set(1);
    this.carregarDados();
  }

  sincronizarComEntraId(): void {
    if (this.sincronizando()) return;

    this.sincronizando.set(true);
    this.toastService.informacao('Sincronização com o Microsoft Entra ID iniciada...');

    this.audienciaService.sincronizarEntraId().subscribe({
      next: (resultado: ResultadoSincronizacao) => {
        this.sincronizando.set(false);
        this.toastService.sucesso(
          `${resultado.mensagem} (${resultado.totalProcessados} processados em ${resultado.duracaoSegundos}s)`
        );
        this.carregarMetadados();
        this.carregarDados();
      },
      error: (err) => {
        this.sincronizando.set(false);
        this.toastService.erro('Falha ao sincronizar dados com o Microsoft Entra ID.');
      }
    });
  }

  mudarPagina(novaPagina: number): void {
    if (novaPagina < 1 || novaPagina > this.totalPaginas()) return;
    this.paginaAtual.set(novaPagina);
    this.carregarDados();
  }

  totalPaginas(): number {
    return Math.ceil(this.totalColaboradores() / this.tamanhoPagina()) || 1;
  }

  obterBadgeClasse(status: string): string {
    switch (status) {
      case 'Elegível':
        return 'badge-status-elegivel';
      case 'Em Cooldown':
        return 'badge-status-cooldown';
      case 'Admitido < 30 dias':
        return 'badge-status-recente';
      case 'Inativo':
      default:
        return 'badge-status-inativo';
    }
  }
}
