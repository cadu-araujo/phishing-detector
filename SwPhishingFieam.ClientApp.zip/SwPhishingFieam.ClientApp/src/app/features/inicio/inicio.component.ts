import { ChangeDetectionStrategy, Component, computed, inject } from '@angular/core';
import { RouterLink } from '@angular/router';
import { AuthService } from '../../core/services/auth.service';
import { HasPermissionDirective } from '../../shared/directives/has-permission.directive';

@Component({
  selector: 'app-inicio',
  imports: [RouterLink, HasPermissionDirective],
  templateUrl: './inicio.component.html',
  styleUrl: './inicio.component.css',
  changeDetection: ChangeDetectionStrategy.OnPush
})
export class InicioComponent {
  private readonly authService = inject(AuthService);

  readonly usuario = this.authService.usuarioAtual;

  readonly saudacao = computed(() => {
    const hora = new Date().getHours();
    if (hora < 12) return 'Bom dia';
    if (hora < 18) return 'Boa tarde';
    return 'Boa noite';
  });

  readonly primeiroNome = computed(() => {
    const usuario = this.usuario();
    if (!usuario?.nome) return 'Operador';
    return usuario.nome.split(' ')[0];
  });

  readonly entidadeNome = computed(() => {
    const usuario = this.usuario();
    if (usuario?.perfis.includes('AdministradorSegurancaGlobal')) {
      return 'Administração Central (Todas as Casas)';
    }
    return 'FIEAM / SESI / SENAI / IEL';
  });
}
