import { ChangeDetectionStrategy, Component, inject, signal } from '@angular/core';
import { FormControl, FormGroup, ReactiveFormsModule, Validators } from '@angular/forms';
import { Router } from '@angular/router';
import { AuthService } from '../../core/services/auth.service';
import { ToastService } from '../../shared/toast/toast.service';

@Component({
  selector: 'app-login',
  imports: [ReactiveFormsModule],
  templateUrl: './login.component.html',
  styleUrl: './login.component.css',
  changeDetection: ChangeDetectionStrategy.OnPush
})
export class LoginComponent {
  private readonly auth = inject(AuthService);
  private readonly roteador = inject(Router);
  private readonly toast = inject(ToastService);

  readonly processando = signal(false);
  readonly mensagemErro = signal<string | null>(null);

  readonly formulario = new FormGroup({
    email: new FormControl('admin.seguranca@fieam.org.br', {
      nonNullable: true,
      validators: [Validators.required, Validators.email]
    }),
    senha: new FormControl('Admin@123456', {
      nonNullable: true,
      validators: [Validators.required]
    })
  });

  entrarComMicrosoft(): void {
    this.toast.informacao('Iniciando autenticação via Microsoft Entra ID...');
    this.entrarComoAdminGlobal();
  }

  entrarComFormulario(): void {
    if (this.formulario.invalid) return;
    const { email } = this.formulario.getRawValue();
    this.executarLoginSso('00000000-0000-0000-0000-000000000001', 'Administrador Global', email);
  }

  entrarComoAdminGlobal(): void {
    this.executarLoginSso(
      '00000000-0000-0000-0000-000000000001',
      'Administrador Global FIEAM',
      'admin.seguranca@fieam.org.br'
    );
  }

  private executarLoginSso(objectId: string, nome: string, email: string): void {
    this.processando.set(true);
    this.mensagemErro.set(null);

    this.auth.autenticarSso(objectId, nome, email).subscribe({
      next: () => {
        this.processando.set(false);
        this.toast.sucesso(`Bem-vindo, ${nome.split(' ')[0]}!`);
        this.roteador.navigate(['/']);
      },
      error: () => {
        this.processando.set(false);
        this.mensagemErro.set('Não foi possível conectar ao servidor. Verifique se a WebApi está em execução.');
        this.toast.erro('Falha na autenticação corporativa.');
      }
    });
  }
}
